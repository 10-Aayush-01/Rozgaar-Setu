require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();

// Middleware to allow frontend to talk to backend
app.use(cors());
app.use(express.json()); // Allows server to read JSON data

// Send traffic to the route files
app.use('/api/auth', require('./routes/auth'));
app.use('/api/workers', require('./routes/workers'));
app.use('/api/contractors', require('./routes/contractors'));

// Health check to test if server is on
app.get('/', (req, res) => res.json({ status: 'Rozgaar Setu API running' }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => console.log(`🚀 Server running on http://localhost:${PORT}`));