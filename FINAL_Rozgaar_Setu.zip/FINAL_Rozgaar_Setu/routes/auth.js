const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');

const router = express.Router();

// 1. REGISTER A WORKER
router.post('/register/worker', async (req, res) => {
    try {
        const { name, username, password, worker_id, daily_rate, shift_date, location, emergency_contact } = req.body;

        const userCheck = await pool.query("SELECT * FROM workers WHERE username = $1", [username]);
        if (userCheck.rows.length > 0) return res.status(400).json({ error: "Username taken" });

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // ADDED: RETURNING * to get the new user data instantly
        const newUser = await pool.query(
            `INSERT INTO workers (name, username, password, worker_id, daily_rate, shift_date, location, emergency_contact) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
            [name, username, hashedPassword, worker_id, daily_rate, shift_date, location, emergency_contact]
        );

        // ADDED: Generate token and return user data (just like login does!)
        const token = jwt.sign({ id: newUser.rows[0].id, role: 'worker' }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.status(201).json({ message: "Worker registered successfully!", token, user: newUser.rows[0] });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Server Error" });
    }
});

// 2. REGISTER A CONTRACTOR
router.post('/register/contractor', async (req, res) => {
    try {
        const { name, username, password, tax_id, service_type, workers_required, wage_offered, work_description } = req.body;

        const userCheck = await pool.query("SELECT * FROM contractors WHERE username = $1", [username]);
        if (userCheck.rows.length > 0) return res.status(400).json({ error: "Username taken" });

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // ADDED: RETURNING * to get the new user data instantly
        const newUser = await pool.query(
            `INSERT INTO contractors (name, username, password, tax_id, service_type, workers_required, wage_offered, work_description) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
            [name, username, hashedPassword, tax_id, service_type, workers_required, wage_offered, work_description]
        );

        // ADDED: Generate token and return user data
        const token = jwt.sign({ id: newUser.rows[0].id, role: 'contractor' }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.status(201).json({ message: "Contractor registered successfully!", token, user: newUser.rows[0] });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Server Error" });
    }
});

// 3. LOGIN (For both workers and contractors)
router.post('/login', async (req, res) => {
    try {
        const { username, password, role } = req.body;
        
        // Determine which table to check based on role
        const tableName = role === 'worker' ? 'workers' : 'contractors';
        
        const user = await pool.query(`SELECT * FROM ${tableName} WHERE username = $1`, [username]);
        
        if (user.rows.length === 0) {
            return res.status(400).json({ error: "User not found" });
        }

        // Compare plain password with scrambled database password
        const validPassword = await bcrypt.compare(password, user.rows[0].password);
        if (!validPassword) {
            return res.status(400).json({ error: "Invalid password" });
        }

        // Create a secure login token
        const token = jwt.sign({ id: user.rows[0].id, role: role }, process.env.JWT_SECRET, { expiresIn: "1h" });

        res.json({ token, user: user.rows[0], message: "Logged in successfully" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Server Error" });
    }
});

module.exports = router;