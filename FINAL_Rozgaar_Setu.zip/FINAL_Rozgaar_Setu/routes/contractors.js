const express = require('express');
const pool = require('../db');
const router = express.Router();

// Get all contractors (exclude passwords)
router.get('/', async (req, res) => {
    try {
        const allContractors = await pool.query(
            "SELECT id, name, username, service_type, workers_required, wage_offered, work_description FROM contractors"
        );
        res.json(allContractors.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: "Server Error" });
    }
});

module.exports = router;