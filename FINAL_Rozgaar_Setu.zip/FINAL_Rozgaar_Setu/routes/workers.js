const express = require('express');
const pool = require('../db');
const router = express.Router();

// Get all workers (exclude passwords for security)
router.get('/', async (req, res) => {
    try {
        const allWorkers = await pool.query(
            "SELECT id, name, username, worker_id, daily_rate, shift_date, location, skill_level, work_type FROM workers"
        );
        res.json(allWorkers.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: "Server Error" });
    }
});

module.exports = router;