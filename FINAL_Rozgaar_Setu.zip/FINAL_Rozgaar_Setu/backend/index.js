const express = require("express");
const app = express();
app.use(express.json());

const workerRoutes = require("./routes/worker");
const contractorRoutes = require("./routes/contractor");
const assignmentRoutes = require("./routes/assignment");

app.use("/worker", workerRoutes);
app.use("/contractor", contractorRoutes);
app.use("/assignment", assignmentRoutes);


app.get('/', (req, res) => {
  res.send('Hello Aayush! The Rozgaar Setu backend is fully working!');
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});