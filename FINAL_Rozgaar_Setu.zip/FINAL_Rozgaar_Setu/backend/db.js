const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "rozgaar_setu",
  password: "postgreys",
  port: 5432,
});

module.exports = pool;