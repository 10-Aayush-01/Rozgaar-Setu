const express = require("express");
const router = express.Router();
const pool = require("../db");

// APPLY
router.post("/apply", async (req, res) => {
  try {
    const { worker_id, contractor_id } = req.body;

    if (!worker_id || !contractor_id) {
      return res.status(400).json({ message: "Missing fields" });
    }

    // prevent duplicate
    const check = await pool.query(
      "SELECT * FROM work_assignment WHERE worker_id=$1 AND contractor_id=$2",
      [worker_id, contractor_id]
    );

    if (check.rows.length > 0) {
      return res.json({ message: "Already applied" });
    }

    // date match
    const worker = await pool.query(
      "SELECT shift_date FROM worker WHERE id=$1",
      [worker_id]
    );

    const contractor = await pool.query(
      "SELECT shift_date FROM contractor WHERE id=$1",
      [contractor_id]
    );

    if (worker.rows.length === 0 || contractor.rows.length === 0) {
      return res.status(404).json({ message: "Invalid worker or contractor" });
    }

    if (!contractor.rows[0].shift_date) {
      return res.json({ message: "Contractor date not set" });
    }

    if (worker.rows[0].shift_date != contractor.rows[0].shift_date) {
      return res.json({ message: "Date mismatch" });
    }

    // insert
    const result = await pool.query(
      `INSERT INTO work_assignment 
       (worker_id, contractor_id, assigned_date, status)
       VALUES ($1,$2,$3,'pending') RETURNING *`,
      [worker_id, contractor_id, worker.rows[0].shift_date]
    );

    res.json(result.rows[0]);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// GET all applicants for a contractor
router.get("/contractor/:id", async (req, res) => {
  try {
    const contractorId = req.params.id;

    const result = await pool.query(
      `SELECT wa.*, w.name, w.skill_level
       FROM work_assignment wa
       JOIN worker w ON wa.worker_id = w.id
       WHERE wa.contractor_id=$1`,
      [contractorId]
    );

    res.json(result.rows);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// UPDATE status
router.post("/update-status", async (req, res) => {
  try {
    const { assignment_id, status } = req.body;

    if (!assignment_id || !status) {
      return res.status(400).json({ message: "Missing fields" });
    }

    if (!["accepted", "rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    await pool.query(
      "UPDATE work_assignment SET status=$1 WHERE id=$2",
      [status, assignment_id]
    );

    res.json({ message: "Updated" });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;