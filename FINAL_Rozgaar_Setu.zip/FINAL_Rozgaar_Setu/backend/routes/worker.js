const express = require("express");
const router = express.Router();
const pool = require("../db");
const bcrypt = require("bcrypt");

// Register worker
router.post("/register", async (req, res) => {
  try {
    const { name, username, password } = req.body;

    if (!name || !username || !password) {
      return res.status(400).json({ message: "Missing fields" });
    }

    const hashed = await bcrypt.hash(password, 10);

    const result = await pool.query(
      "INSERT INTO worker (name, username, password) VALUES ($1,$2,$3) RETURNING *",
      [name, username, hashed]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// Match contractors
router.get("/match/:workerId", async (req, res) => {
  try {
    const workerId = req.params.workerId;

    const worker = await pool.query(
      "SELECT work_type FROM worker WHERE id=$1",
      [workerId]
    );

    if (worker.rows.length === 0) {
      return res.status(404).json({ message: "Worker not found" });
    }

    const result = await pool.query(
      `SELECT * FROM contractor WHERE service_type = $1`,
      [worker.rows[0].work_type]
    );

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;