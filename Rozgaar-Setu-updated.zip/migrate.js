require('dotenv').config();
const pool = require('./db');

(async () => {
  try {
    // Add work_date column if it doesn't exist
    await pool.query(`
      DO $$ 
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM information_schema.columns 
          WHERE table_name = 'contractors' AND column_name = 'work_date'
        ) THEN
          ALTER TABLE contractors ADD COLUMN work_date DATE DEFAULT CURRENT_DATE;
        END IF;
      END $$;
    `);
    console.log('✅ work_date column ensured');

    // Drop workers_required column if it exists
    await pool.query(`
      DO $$ 
      BEGIN
        IF EXISTS (
          SELECT 1 FROM information_schema.columns 
          WHERE table_name = 'contractors' AND column_name = 'workers_required'
        ) THEN
          ALTER TABLE contractors DROP COLUMN workers_required;
        END IF;
      END $$;
    `);
    console.log('✅ workers_required column removed');

    // Update any NULL work_date to today
    await pool.query(`UPDATE contractors SET work_date = CURRENT_DATE WHERE work_date IS NULL`);
    console.log('✅ Existing contractors updated with today as work_date');

    // Also update work_assignments status from old values to new format
    await pool.query(`UPDATE work_assignments SET status = 'worker_accepted' WHERE status IN ('assigned', 'accepted')`);
    console.log('✅ Old statuses migrated to new format');

    console.log('\n🎉 Migration complete!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Migration error:', err.message);
    process.exit(1);
  }
})();
