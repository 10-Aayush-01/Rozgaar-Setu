require('dotenv').config();
const pool = require('./db');
pool.query(`SELECT wa.id, wa.worker_id, wa.contractor_id, wa.status,
  w.name as wname, c.name as cname
  FROM work_assignments wa
  JOIN workers w ON wa.worker_id = w.id
  JOIN contractors c ON wa.contractor_id = c.id`)
  .then(r => {
    console.log('=== ALL ASSIGNMENTS ===');
    r.rows.forEach(a => console.log('  #' + a.id + ' ' + a.wname + ' -> ' + a.cname + '  status=' + a.status));
    if (r.rows.length === 0) console.log('  (none)');
    process.exit(0);
  })
  .catch(e => { console.error(e.message); process.exit(1); });
