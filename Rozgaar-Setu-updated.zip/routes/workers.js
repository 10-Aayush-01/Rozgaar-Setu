const express = require('express');
const router = express.Router();
const pool = require('../db');
const authenticateToken = require('../middleware/auth');

/**
 * GET /api/workers
 * Returns all workers (passwords excluded)
 * Used by contractors to browse available workers
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, username, worker_id, daily_rate, shift_date, shift_type,
              location, skill_level, advance_taken, emergency_contact, work_type, image
       FROM workers
       ORDER BY id DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching workers:', err);
    res.status(500).json({ error: 'Server error fetching workers.' });
  }
});

/**
 * GET /api/workers/:id
 * Returns a single worker profile (password excluded)
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, username, worker_id, daily_rate, shift_date, shift_type,
              location, skill_level, advance_taken, emergency_contact, work_type, image
       FROM workers WHERE id = $1`,
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Worker not found.' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error fetching worker:', err);
    res.status(500).json({ error: 'Server error fetching worker.' });
  }
});

/**
 * PUT /api/workers/:id
 * Update a worker's editable profile fields
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id: userId, role } = req.user;
    if (role !== 'worker' || userId !== Number(req.params.id)) {
      return res.status(403).json({ error: 'You can only edit your own profile.' });
    }
    const { daily_rate, shift_date, shift_type, location, work_type, emergency_contact } = req.body;
    const result = await pool.query(
      `UPDATE workers SET daily_rate = COALESCE($1, daily_rate), shift_date = COALESCE($2, shift_date),
        shift_type = COALESCE($3, shift_type), location = COALESCE($4, location),
        work_type = COALESCE($5, work_type), emergency_contact = COALESCE($6, emergency_contact)
       WHERE id = $7
       RETURNING id, name, username, worker_id, daily_rate, shift_date, shift_type,
                 location, skill_level, advance_taken, emergency_contact, work_type, image`,
      [daily_rate, shift_date, shift_type, location, work_type, emergency_contact, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error updating worker:', err);
    res.status(500).json({ error: 'Server error updating profile.' });
  }
});

module.exports = router;
