const express = require('express');
const router = express.Router();
const pool = require('../db');
const authenticateToken = require('../middleware/auth');

/**
 * POST /api/assignments
 * Create a new draft/proposal.
 * Body: { worker_id, contractor_id, message? }
 * Status is auto-set based on who sends it:
 *   - worker sends  → draft_by_worker
 *   - contractor sends → draft_by_contractor
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { worker_id, contractor_id, message } = req.body;
    const { id: senderId, role: senderRole } = req.user;

    if (!worker_id || !contractor_id) {
      return res.status(400).json({ error: 'worker_id and contractor_id are required.' });
    }

    // Validate that the sender is who they claim to be
    if (senderRole === 'worker' && Number(worker_id) !== senderId) {
      return res.status(403).json({ error: 'You can only send proposals as yourself.' });
    }
    if (senderRole === 'contractor' && Number(contractor_id) !== senderId) {
      return res.status(403).json({ error: 'You can only send offers as yourself.' });
    }

    // Check the worker exists and get their profile data for the snapshot
    const workerResult = await pool.query(
      'SELECT id, name, username, worker_id, daily_rate, shift_date, shift_type, location, skill_level, work_type, image FROM workers WHERE id = $1', 
      [worker_id]
    );
    if (workerResult.rows.length === 0) {
      return res.status(404).json({ error: 'Worker not found.' });
    }
    const worker = workerResult.rows[0];

    // Check the contractor exists and get their profile data for the snapshot
    const contractorResult = await pool.query(
      'SELECT id, name, username, tax_id, service_type, wage_offered, work_date, work_description, image FROM contractors WHERE id = $1', 
      [contractor_id]
    );
    if (contractorResult.rows.length === 0) {
      return res.status(404).json({ error: 'Contractor not found.' });
    }
    const contractor = contractorResult.rows[0];

    // Empty date validation
    if (!worker.shift_date) {
      return res.status(400).json({ error: 'Worker must set a shift date before proposals can be sent.' });
    }
    if (!contractor.work_date) {
      return res.status(400).json({ error: 'Contractor must set a work date before proposals can be sent.' });
    }

    // Get today's date as YYYY-MM-DD string (timezone-safe)
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;

    if (worker.shift_date && worker.shift_date < todayStr) {
      return res.status(400).json({
        error: `Worker's shift date (${worker.shift_date}) is in the past.`
      });
    }

    if (contractor.work_date && contractor.work_date < todayStr) {
      return res.status(400).json({
        error: `Contractor's work date (${contractor.work_date}) is in the past.`
      });
    }

    // Date match validation: worker shift_date must match contractor work_date
    if (worker.shift_date && contractor.work_date && worker.shift_date !== contractor.work_date) {
      return res.status(400).json({
        error: `Date mismatch: Worker available on ${worker.shift_date}, Contractor needs on ${contractor.work_date}. Dates must match.`
      });
    }

    // Check for existing active proposal (pending or accepted) between this pair
    const existing = await pool.query(
      `SELECT id, status FROM work_assignments
       WHERE worker_id = $1 AND contractor_id = $2
       AND status IN ('draft_by_worker', 'draft_by_contractor', 'worker_accepted', 'contractor_accepted')`,
      [worker_id, contractor_id]
    );
    if (existing.rows.length > 0) {
      const s = existing.rows[0].status;
      if (s.endsWith('_accepted')) {
        return res.status(409).json({ error: 'This worker-contractor pair is already matched!' });
      }
      return res.status(409).json({ error: 'A pending proposal already exists between these two.' });
    }

    // If there was a rejected one, delete it so a fresh one can be created
    await pool.query(
      `DELETE FROM work_assignments
       WHERE worker_id = $1 AND contractor_id = $2 AND status IN ('worker_rejected', 'contractor_rejected')`,
      [worker_id, contractor_id]
    );

    const status = senderRole === 'worker' ? 'draft_by_worker' : 'draft_by_contractor';

    // Build the frozen snapshot of both parties
    const snapshot = {
      worker: worker,
      contractor: contractor
    };

    const result = await pool.query(
      `INSERT INTO work_assignments (worker_id, contractor_id, status, assigned_date, snapshot)
       VALUES ($1, $2, $3, CURRENT_DATE, $4)
       RETURNING *`,
      [worker_id, contractor_id, status, snapshot]
    );

    res.status(201).json({
      message: senderRole === 'worker'
        ? 'Proposal sent to contractor!'
        : 'Offer sent to worker!',
      assignment: result.rows[0]
    });
  } catch (err) {
    console.error('Error creating proposal:', err);
    if (err.code === '23505') {
      return res.status(409).json({ error: 'A proposal already exists between these two.' });
    }
    res.status(500).json({ error: 'Server error creating proposal.' });
  }
});

/**
 * GET /api/assignments/mine
 * Returns the logged-in user's proposals split into incoming and outgoing.
 * Each item includes full details of the other party.
 */
router.get('/mine', authenticateToken, async (req, res) => {
  try {
    const { id, role } = req.user;

    let incoming, outgoing;

    if (role === 'worker') {
      // Incoming = pending offers FROM contractors (needs my action)
      incoming = await pool.query(
        `SELECT wa.id as assignment_id, wa.assigned_date, wa.status, wa.action_by, wa.snapshot,
                c.id, c.name, c.username, c.tax_id, c.service_type,
                c.wage_offered, c.work_date, c.work_description, c.image
         FROM work_assignments wa
         JOIN contractors c ON wa.contractor_id = c.id
         WHERE wa.worker_id = $1 AND wa.status = 'draft_by_contractor'
         ORDER BY wa.assigned_date DESC`,
        [id]
      );

      // History = everything else (my sent proposals + resolved items from either side)
      outgoing = await pool.query(
        `SELECT wa.id as assignment_id, wa.assigned_date, wa.status, wa.action_by, wa.snapshot,
                c.id, c.name, c.username, c.tax_id, c.service_type,
                c.wage_offered, c.work_date, c.work_description, c.image
         FROM work_assignments wa
         JOIN contractors c ON wa.contractor_id = c.id
         WHERE wa.worker_id = $1 AND wa.status != 'draft_by_contractor'
         ORDER BY wa.assigned_date DESC`,
        [id]
      );
    } else {
      // Incoming = pending proposals FROM workers (needs my action)
      incoming = await pool.query(
        `SELECT wa.id as assignment_id, wa.assigned_date, wa.status, wa.action_by, wa.snapshot,
                w.id, w.name, w.username, w.worker_id as wid, w.daily_rate,
                w.shift_date, w.shift_type, w.location, w.skill_level,
                w.work_type, w.image
         FROM work_assignments wa
         JOIN workers w ON wa.worker_id = w.id
         WHERE wa.contractor_id = $1 AND wa.status = 'draft_by_worker'
         ORDER BY wa.assigned_date DESC`,
        [id]
      );

      // History = everything else (my sent offers + resolved items from either side)
      outgoing = await pool.query(
        `SELECT wa.id as assignment_id, wa.assigned_date, wa.status, wa.action_by, wa.snapshot,
                w.id, w.name, w.username, w.worker_id as wid, w.daily_rate,
                w.shift_date, w.shift_type, w.location, w.skill_level,
                w.work_type, w.image
         FROM work_assignments wa
         JOIN workers w ON wa.worker_id = w.id
         WHERE wa.contractor_id = $1 AND wa.status != 'draft_by_worker'
         ORDER BY wa.assigned_date DESC`,
        [id]
      );
    }

    res.json({
      incoming: incoming.rows,
      outgoing: outgoing.rows
    });
  } catch (err) {
    console.error('Error fetching proposals:', err);
    res.status(500).json({ error: 'Server error fetching proposals.' });
  }
});

/**
 * PATCH /api/assignments/:id/accept
 * Only the receiver can accept.
 * - If status is draft_by_worker → only contractor can accept
 * - If status is draft_by_contractor → only worker can accept
 */
router.patch('/:id/accept', authenticateToken, async (req, res) => {
  try {
    const assignmentId = req.params.id;
    const { id: userId, role: userRole } = req.user;

    // Fetch the assignment
    const result = await pool.query('SELECT * FROM work_assignments WHERE id = $1', [assignmentId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Proposal not found.' });
    }

    const assignment = result.rows[0];

    // Only pending drafts can be accepted
    if (!assignment.status.startsWith('draft_by_')) {
      return res.status(400).json({ error: `Cannot accept a proposal with status: ${assignment.status}` });
    }

    // Verify the receiver is the one accepting
    if (assignment.status === 'draft_by_worker' && (userRole !== 'contractor' || assignment.contractor_id !== userId)) {
      return res.status(403).json({ error: 'Only the receiving contractor can accept this proposal.' });
    }
    if (assignment.status === 'draft_by_contractor' && (userRole !== 'worker' || assignment.worker_id !== userId)) {
      return res.status(403).json({ error: 'Only the receiving worker can accept this offer.' });
    }

    // Use actor-prefixed status so it's clear WHO accepted it
    const newStatus = assignment.status === 'draft_by_worker' ? 'contractor_accepted' : 'worker_accepted';
    await pool.query(
      `UPDATE work_assignments SET status = $1, assigned_date = CURRENT_DATE, action_by = $2 WHERE id = $3`,
      [newStatus, userRole, assignmentId]
    );

    res.json({ message: 'Proposal accepted! ✅', assignmentId });
  } catch (err) {
    console.error('Error accepting proposal:', err);
    res.status(500).json({ error: 'Server error accepting proposal.' });
  }
});

/**
 * PATCH /api/assignments/:id/reject
 * Only the receiver can reject.
 */
router.patch('/:id/reject', authenticateToken, async (req, res) => {
  try {
    const assignmentId = req.params.id;
    const { id: userId, role: userRole } = req.user;

    const result = await pool.query('SELECT * FROM work_assignments WHERE id = $1', [assignmentId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Proposal not found.' });
    }

    const assignment = result.rows[0];

    if (!assignment.status.startsWith('draft_by_')) {
      return res.status(400).json({ error: `Cannot reject a proposal with status: ${assignment.status}` });
    }

    // Verify the receiver is the one rejecting
    if (assignment.status === 'draft_by_worker' && (userRole !== 'contractor' || assignment.contractor_id !== userId)) {
      return res.status(403).json({ error: 'Only the receiving contractor can reject this proposal.' });
    }
    if (assignment.status === 'draft_by_contractor' && (userRole !== 'worker' || assignment.worker_id !== userId)) {
      return res.status(403).json({ error: 'Only the receiving worker can reject this offer.' });
    }

    // Use actor-prefixed status so it's clear WHO rejected it
    const newStatus = assignment.status === 'draft_by_worker' ? 'contractor_rejected' : 'worker_rejected';
    await pool.query(
      `UPDATE work_assignments SET status = $1, action_by = $2 WHERE id = $3`,
      [newStatus, userRole, assignmentId]
    );

    res.json({ message: 'Proposal rejected.', assignmentId });
  } catch (err) {
    console.error('Error rejecting proposal:', err);
    res.status(500).json({ error: 'Server error rejecting proposal.' });
  }
});

/**
 * DELETE /api/assignments/:id
 * Delete a rejected proposal (archive/clear).
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const { id: userId, role: userRole } = req.user;
    const result = await pool.query('SELECT * FROM work_assignments WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Proposal not found.' });
    }
    const a = result.rows[0];
    // Only rejected proposals can be cleared
    if (!a.status.endsWith('_rejected')) {
      return res.status(400).json({ error: 'Only rejected proposals can be cleared.' });
    }
    // Only involved parties can delete
    if ((userRole === 'worker' && a.worker_id !== userId) ||
        (userRole === 'contractor' && a.contractor_id !== userId)) {
      return res.status(403).json({ error: 'You can only clear your own proposals.' });
    }
    await pool.query('DELETE FROM work_assignments WHERE id = $1', [req.params.id]);
    res.json({ message: 'Proposal cleared.' });
  } catch (err) {
    console.error('Error deleting proposal:', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
