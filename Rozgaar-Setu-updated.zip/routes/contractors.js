const express = require('express');
const router = express.Router();
const pool = require('../db');
const authenticateToken = require('../middleware/auth');

/**
 * GET /api/contractors
 * Returns all contractors (passwords excluded)
 * Used by workers to browse available job postings
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, username, tax_id, service_type,
              wage_offered, work_date, work_description, image
       FROM contractors
       ORDER BY id DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching contractors:', err);
    res.status(500).json({ error: 'Server error fetching contractors.' });
  }
});

/**
 * GET /api/contractors/:id
 * Returns a single contractor profile (password excluded)
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, username, tax_id, service_type,
              wage_offered, work_date, work_description, image
       FROM contractors WHERE id = $1`,
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Contractor not found.' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error fetching contractor:', err);
    res.status(500).json({ error: 'Server error fetching contractor.' });
  }
});

/**
 * PUT /api/contractors/:id
 * Update a contractor's editable profile fields
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id: userId, role } = req.user;
    if (role !== 'contractor' || userId !== Number(req.params.id)) {
      return res.status(403).json({ error: 'You can only edit your own profile.' });
    }
    const { wage_offered, work_date, service_type, work_description } = req.body;
    const result = await pool.query(
      `UPDATE contractors SET wage_offered = COALESCE($1, wage_offered), work_date = COALESCE($2, work_date),
        service_type = COALESCE($3, service_type), work_description = COALESCE($4, work_description)
       WHERE id = $5
       RETURNING id, name, username, tax_id, service_type, wage_offered, work_date, work_description, image`,
      [wage_offered, work_date, service_type, work_description, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error updating contractor:', err);
    res.status(500).json({ error: 'Server error updating profile.' });
  }
});

module.exports = router;
