const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const admin = require('firebase-admin');

// Firebase Admin Init - only required in PROD, guard against double-init
if (process.env.TEST_MODE !== 'true') {
  try {
    if (!admin.apps.length) {
      const serviceAccount = require('../serviceAccountKey.json');
      admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
      console.log('✅ Firebase Admin initialized.');
    }
  } catch(e) {
    console.warn("⚠️ Firebase Admin failed to initialize:", e.message);
  }
}

/**
 * GET /api/auth/config
 */
router.get('/config', (req, res) => {
  res.json({ testMode: process.env.TEST_MODE === 'true' });
});

// In-memory store for test OTPs (TEST_MODE only)
const testOTPStore = {};

/**
 * POST /api/auth/test-otp/send
 */
router.post('/test-otp/send', (req, res) => {
  if (process.env.TEST_MODE !== 'true') {
    return res.status(403).json({ error: 'Only available in TEST_MODE.' });
  }
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'Phone is required.' });

  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  testOTPStore[phone] = { otp, createdAt: new Date().toISOString() };

  console.log(`📱 Test OTP for ${phone}: ${otp}`);
  res.json({ success: true, message: `OTP generated for ${phone}` });
});

/**
 * GET /api/auth/test-otp/inbox
 */
router.get('/test-otp/inbox', (req, res) => {
  if (process.env.TEST_MODE !== 'true') {
    return res.status(403).json({ error: 'Only available in TEST_MODE.' });
  }
  const rows = Object.entries(testOTPStore).map(([phone, data]) => `
    <tr>
      <td>+91${phone}</td>
      <td><strong style="font-size:1.4rem;letter-spacing:4px;color:#e88c2f">${data.otp}</strong></td>
      <td>${data.createdAt}</td>
    </tr>
  `).join('') || '<tr><td colspan="3" style="text-align:center;color:#888">No OTPs sent yet</td></tr>';

  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Test OTP Inbox</title>
      <meta http-equiv="refresh" content="5">
      <style>
        body { font-family: sans-serif; background: #1a1008; color: #faf3e8; padding: 2rem; }
        h1 { color: #e88c2f; }
        p { color: #8a7560; margin-bottom: 1.5rem; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #2a1c0e; color: #e88c2f; padding: 0.8rem 1rem; text-align: left; }
        td { padding: 0.8rem 1rem; border-bottom: 1px solid #2a1c0e; }
        tr:hover td { background: rgba(232,140,47,0.05); }
        .badge { background: #2a1c0e; padding: 0.2rem 0.6rem; border-radius: 999px; font-size: 0.75rem; color: #e88c2f; }
      </style>
    </head>
    <body>
      <h1>📱 Test OTP Inbox</h1>
      <p>Auto-refreshes every 5 seconds. OTPs are stored in memory (cleared on server restart).</p>
      <span class="badge">TEST MODE ONLY</span>
      <br><br>
      <table>
        <thead>
          <tr><th>Phone Number</th><th>OTP</th><th>Sent At</th></tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </body>
    </html>
  `);
});

/**
 * POST /api/auth/test-otp/verify
 */
router.post('/test-otp/verify', (req, res) => {
  if (process.env.TEST_MODE !== 'true') {
    return res.status(403).json({ error: 'Only available in TEST_MODE.' });
  }
  const { phone, otp } = req.body;
  if (!phone || !otp) return res.status(400).json({ error: 'Phone and OTP are required.' });

  const stored = testOTPStore[phone];
  if (!stored) return res.status(400).json({ error: 'No OTP sent to this number. Click Send OTP first.' });
  if (stored.otp !== otp) return res.status(401).json({ error: 'Incorrect OTP. Please check your inbox.' });

  delete testOTPStore[phone];
  res.json({ success: true, token: 'DUMMY_TEST_TOKEN' });
});

/**
 * POST /api/auth/register/worker
 */
router.post('/register/worker', async (req, res) => {
  try {
    const {
      name, username, password, worker_id,
      daily_rate, shift_date, shift_type, location,
      skill_level, advance_taken, emergency_contact,
      work_type, image, phone, otp_token
    } = req.body;

    if (!phone || !otp_token) {
      return res.status(400).json({ error: 'Phone number and OTP token are required for registration.' });
    }

    if (process.env.TEST_MODE === 'true') {
      if (otp_token !== 'DUMMY_TEST_TOKEN') {
        return res.status(401).json({ error: 'Invalid TEST OTP Token' });
      }
    } else {
      try {
        await admin.auth().verifyIdToken(otp_token);
      } catch(e) {
        return res.status(401).json({ error: 'Invalid Firebase OTP Token' });
      }
    }

    const existing = await pool.query('SELECT id FROM workers WHERE username = $1', [username.toLowerCase()]);
    if (existing.rows.length > 0) return res.status(409).json({ error: 'Username already taken.' });

    const existingPhone = await pool.query('SELECT id FROM workers WHERE phone = $1', [phone]);
    if (existingPhone.rows.length > 0) return res.status(409).json({ error: 'Phone number already registered.' });

    const existingId = await pool.query('SELECT id FROM workers WHERE worker_id = $1', [worker_id]);
    if (existingId.rows.length > 0) return res.status(409).json({ error: 'Worker ID already exists.' });

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const result = await pool.query(
      `INSERT INTO workers 
        (name, username, password, worker_id, daily_rate, shift_date, shift_type, 
         location, skill_level, advance_taken, emergency_contact, work_type, image, phone)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       RETURNING id, name, username, worker_id, daily_rate, shift_date, shift_type,
                 location, skill_level, advance_taken, emergency_contact, work_type, image, phone`,
      [name, username.toLowerCase(), hashedPassword, worker_id, daily_rate, shift_date, shift_type,
       location, skill_level, advance_taken || 0, emergency_contact, work_type, image, phone]
    );

    const worker = result.rows[0];
    const token = jwt.sign({ id: worker.id, role: 'worker', username: worker.username }, process.env.JWT_SECRET, { expiresIn: '24h' });

    res.status(201).json({ message: 'Worker registered successfully!', token, user: worker });
  } catch (err) {
    console.error('Worker registration error:', err);
    res.status(500).json({ error: 'Server error during registration.' });
  }
});

/**
 * POST /api/auth/register/contractor
 */
router.post('/register/contractor', async (req, res) => {
  try {
    const {
      name, username, password, tax_id,
      service_type, wage_offered,
      work_date, work_description, image, phone, otp_token
    } = req.body;

    if (!phone || !otp_token) {
      return res.status(400).json({ error: 'Phone number and OTP token are required for registration.' });
    }

    if (process.env.TEST_MODE === 'true') {
      if (otp_token !== 'DUMMY_TEST_TOKEN') {
        return res.status(401).json({ error: 'Invalid TEST OTP Token' });
      }
    } else {
      try {
        await admin.auth().verifyIdToken(otp_token);
      } catch(e) {
        return res.status(401).json({ error: 'Invalid Firebase OTP Token' });
      }
    }

    const existing = await pool.query('SELECT id FROM contractors WHERE username = $1', [username.toLowerCase()]);
    if (existing.rows.length > 0) return res.status(409).json({ error: 'Username already taken.' });

    const existingPhone = await pool.query('SELECT id FROM contractors WHERE phone = $1', [phone]);
    if (existingPhone.rows.length > 0) return res.status(409).json({ error: 'Phone number already registered.' });

    const existingTax = await pool.query('SELECT id FROM contractors WHERE tax_id = $1', [tax_id]);
    if (existingTax.rows.length > 0) return res.status(409).json({ error: 'GST / Tax ID already registered.' });

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const result = await pool.query(
      `INSERT INTO contractors 
        (name, username, password, tax_id, service_type, 
         wage_offered, work_date, work_description, image, phone)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING id, name, username, tax_id, service_type,
                 wage_offered, work_date, work_description, image, phone`,
      [name, username.toLowerCase(), hashedPassword, tax_id, service_type, wage_offered, work_date, work_description, image, phone]
    );

    const contractor = result.rows[0];
    const token = jwt.sign({ id: contractor.id, role: 'contractor', username: contractor.username }, process.env.JWT_SECRET, { expiresIn: '24h' });

    res.status(201).json({ message: 'Contractor registered successfully!', token, user: contractor });
  } catch (err) {
    console.error('Contractor registration error:', err);
    res.status(500).json({ error: 'Server error during registration.' });
  }
});

/**
 * POST /api/auth/login
 */
router.post('/login', async (req, res) => {
  try {
    const { role, username, password, phone, otp_token } = req.body;

    if (!role) return res.status(400).json({ error: 'Role is required.' });

    const table = role === 'worker' ? 'workers' : 'contractors';
    let user;

    if (phone && otp_token) {
      if (process.env.TEST_MODE === 'true') {
        if (otp_token !== 'DUMMY_TEST_TOKEN') {
          return res.status(401).json({ error: 'Invalid TEST OTP Token' });
        }
      } else {
        try {
          await admin.auth().verifyIdToken(otp_token);
        } catch(e) {
          return res.status(401).json({ error: 'Invalid Firebase OTP Token' });
        }
      }

      const result = await pool.query(`SELECT * FROM ${table} WHERE phone = $1`, [phone]);
      if (result.rows.length === 0) {
        return res.status(401).json({ error: 'No account registered with this phone number.', errorType: 'phone_not_found' });
      }
      user = result.rows[0];

    } else if (username && password) {
      const result = await pool.query(`SELECT * FROM ${table} WHERE username = $1`, [username.toLowerCase()]);
      if (result.rows.length === 0) {
        return res.status(401).json({ error: 'No account found with that username.', errorType: 'username_not_found' });
      }
      user = result.rows[0];

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: 'Incorrect password.', errorType: 'wrong_password' });
      }
    } else {
      return res.status(400).json({ error: 'Must provide either username+password OR phone+otp_token.' });
    }

    const token = jwt.sign({ id: user.id, role, username: user.username }, process.env.JWT_SECRET, { expiresIn: '24h' });
    const { password: _, ...safeUser } = user;

    res.json({ message: 'Login successful!', token, role, user: safeUser });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

module.exports = router;
