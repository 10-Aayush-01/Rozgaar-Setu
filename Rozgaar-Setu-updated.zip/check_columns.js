const pool = require('./db.js');
pool.query(
  "SELECT table_name, column_name, data_type FROM information_schema.columns WHERE table_name IN ('workers','contractors') ORDER BY table_name, ordinal_position"
).then(r => {
  console.log('\n=== DATABASE COLUMNS ===');
  let currentTable = '';
  r.rows.forEach(row => {
    if (row.table_name !== currentTable) {
      currentTable = row.table_name;
      console.log('\n--- ' + currentTable.toUpperCase() + ' ---');
    }
    console.log('  ' + row.column_name + ' (' + row.data_type + ')');
  });
  process.exit(0);
}).catch(e => { console.error(e); process.exit(1); });
